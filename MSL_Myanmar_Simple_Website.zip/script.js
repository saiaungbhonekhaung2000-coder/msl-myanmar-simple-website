const matches = [
  {date:"Matchday 1", time:"7:00 PM", a:"Team Alpha", b:"Team Bravo"},
  {date:"Matchday 2", time:"8:30 PM", a:"Team Delta", b:"Team Echo"},
  {date:"Matchday 3", time:"7:00 PM", a:"Team Nova", b:"Team Alpha"}
];

const standings = [
  ["Team Alpha", 4, 1, 12],
  ["Team Bravo", 3, 2, 9],
  ["Team Delta", 3, 2, 9],
  ["Team Echo", 2, 3, 6],
  ["Team Nova", 1, 4, 3]
];

const teams = ["Team Alpha","Team Bravo","Team Delta","Team Echo","Team Nova","Team Phoenix"];

document.querySelector("#match-list").innerHTML = matches.map(m => `
  <article class="match">
    <div class="match-date">${m.date} · ${m.time}</div>
    <div class="teams"><span>${m.a}</span><span class="vs">VS</span><span>${m.b}</span></div>
  </article>`).join("");

document.querySelector("#standings-body").innerHTML = standings.map((t,i) => `
  <tr><td class="rank">${i+1}</td><td>${t[0]}</td><td>${t[1]}</td><td>${t[2]}</td><td>${t[3]}</td></tr>`).join("");

document.querySelector("#team-list").innerHTML = teams.map(t => `
  <article class="team"><div class="badge">${t.split(" ").map(x=>x[0]).join("")}</div>
  <div><strong>${t}</strong><small>Myanmar MLBB Team</small></div></article>`).join("");
